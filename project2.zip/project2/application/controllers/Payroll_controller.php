<?php
class Payroll_controller extends CI_Controller{

    public function payroll(){
        $this->load->view('template/header');
        $this->load->view('payroll');
        $this->load->view('template/footer');

    }

    public function pay(){
    $res = $this->Payroll_model->pay();

    $var="None";
    $data['name'] = $res['name'];
    $data['pos'] = $res['pos'];
    $data['sal'] = $res['sal'];
    $data['gros'] = $res['gros'];
    $data['sss'] = $res['sss'];
    $data['pag'] = $res['pag'];
    $data['tax'] = $res['tax'];
    $data['grod'] = $res['grod'];
    $data['pout'] = $res['pout'];
    $page = "pay";
    $this->load->view('template/header');
    $this->load->view($page,$data);
    $this->load->view('template/footer');
    
    

}
}


   

