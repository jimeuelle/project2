<?php
class Login_model extends CI_Model{

    public function logindata(){
        $fname = "Jonnel";
        $lname = "Alonzo";
        $mname = "Mangalino";
        return $lname.', '.$fname.', '.$mname;

    }


    public function myData(){
        $age = 20;
        $add = "Candaba Pampanga";
        $gender = "Male";
        $bday = "Feb 21, 2002";
        $occp = "N/A";
        
     $mdata = array(
        'age' => $age,
        'add' => $add,
        'gender' => $gender,
        'bday' => $bday,
        'occp' => $occp,
        'email' => $this -> input -> post('email'),
        'pswd' => $this -> input -> post('pswd')

     );
     return $mdata;

    }


    public function authenticate(){
        $u = "admin";
        $p = "pass";
        $email = $this -> input -> post('email');
        $pass = $this -> input -> post('pswd');

        if ($email == $u and $pass == $p){
            return "success";
        }
        else{
            return "error";
        }
      
        

    }
    

}