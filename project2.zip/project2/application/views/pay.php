<<style>
body {
  background-image: url('hcc.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>




<div class="container">
    <h1>This is your computation of your salary! </h1>
    <div class="col-13 p-6 bg-primary">

        <h2>Name : <?= $name;?></h2>
        <h2>Position: <?= $pos;?></h2>  
        <h2>Salary: <?= $sal;?></h2>  
        <h2>Gros Salary: <?= $gros;?></h2> 
        <h1> ======================================= </h1> 
        <h1>Contribution:</h1>
        <h2>SSS: <?= $sss;?></h2>  
        <h2>Pag ibig: <?= $pag;?></h2>  
        <h2>Tax: <?= $tax;?></h2>  
        <h2>Gross Deduction: <?= $grod;?></h2> 
        <h2>Pay-Out: <?= $pout;?> </h2>




        
    </div> 
    </div>
</div>