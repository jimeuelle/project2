<?php
class Admin_model extends CI_Model{

    public function compute(){
        $p = $this -> input -> post('prelim');
        $m = $this -> input -> post('midterm');
        $f = $this -> input -> post('finals');

        $Final = ($p*.30)+($m*.30)+($p*.40);

        if($Final>74){
            $res = array(
            
            'pre' =>$p,
            'mid' =>$m,
            'fin' =>$f,
            'fgrade'=>$Final,
            'rem' => 'Passed'
            );
        }else{
            $res = array(
        
            'pre' =>$p,
            'mid' =>$m,
            'fin' =>$f,
            'fgrade'=>$Final,
            'rem' => 'Failed'
            ); 
        }
        return $res;
    }
}