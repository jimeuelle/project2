<?php
class Admin_controller extends CI_Controller{

    public function gradeCompute(){
        $var="None";
        $data['prelim'] = $var;
        $data['midterm'] = $var;
        $data['final'] =  $var;
        $data['remarks'] = $var;
        $data['finalgrade']= $var;

        $this->load->view('template/header');
        $this->load->view('grade',$data);
        $this->load->view('template/footer');
        
       
    
            
    }
    public function compute(){
        $res = $this->Admin_model->compute();

        $data['prelim'] = $res['pre'];
        $data['midterm'] = $res['mid'];
        $data['final'] = $res['fin'];
        $data['remarks'] = $res['rem'];
        $data['finalgrade']= $res['fgrade'];

        $this->load->view('template/header');
        $this->load->view('grade',$data);
        $this->load->view('template/footer');
    }
    
}