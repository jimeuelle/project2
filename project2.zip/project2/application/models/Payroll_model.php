<?php
class Payroll_model extends CI_Model{

    public function pay(){
        $name = $this -> input -> post('name');
        $pos = $this -> input -> post('position');
        $pre = $this -> input -> post('present');

        $jr =  $pre*1000;
        $mid =  $pre*2000;
        $sr =  $pre*4000;
        $pro =  $pre*5000;
        
    
        if($pos=="Junior Programmer"){
            $sss = $jr*.08;
            $pag = $jr*.07;
            $tax = 0;
            $grod = $pag+$sss+$tax;
            $out = $jr-$grod;
            
            $res = array(
            'name' =>$name,
            'pos' =>$pos,
            'sal' =>20000,
            'gros'=>$jr,
            'sss' => $sss,
            'pag' => $pag,
            'tax' => $tax,
            'grod' => $grod,
            'pout' => $out
            );


        }elseif($pos=="Mid Programmer"){
            $sss = $mid*.08;
            $pag = $mid*.07;
            $tax = $mid*.12;
            $grod = $pag+$sss+$tax;
            $out = $mid-$grod;
            
            $res = array(
            'name' =>$name,
            'pos' =>$pos,
            'sal' =>40000,
            'gros'=>$mid,
            'sss' => $sss,
            'pag' => $pag,
            'tax' => $tax,
            'grod' => $grod,
            'pout' => $out
            );

        }elseif($pos=="Senior Programmer"){
            $sss = $sr*.08;
            $pag = $sr*.07;
            $tax = $sr*.12;
            $grod = $pag+$sss+$tax;
            $out = $sr-$grod;
            
            $res = array(
            'name' =>$name,
            'pos' =>$pos,
            'sal' =>80000,
            'gros'=>$sr,
            'sss' => $sss,
            'pag' => $pag,
            'tax' => $tax,
            'grod' => $grod,
            'pout' => $out
            );

        }elseif($pos=="Project Manager"){
            $sss = $pro*.08;
            $pag = $pro*.07;
            $tax = $pro*.12;
            $grod = $pag+$sss+$tax;
            $out = $pro-$grod;
            
            $res = array(
            'name' =>$name,
            'pos' =>$pos,
            'sal' =>100000,
            'gros'=>$pro,
            'sss' => $sss,
            'pag' => $pag,
            'tax' => $tax,
            'grod' => $grod,
            'pout' => $out
            );
        }
        return $res;
    }
}