<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['hello'] = 'Hello_controller/sayHello';

$route['register'] = 'Login_controller/login';

$route['default_controller'] = 'Login_controller/login';

$route['authenticate'] = 'Login_controller/authenticate';

$route['dashboard'] ='Dashboard_controller/dashboard';

$route['gradecompute'] ='Admin_controller/gradeCompute';

$route['compute'] ='Admin_controller/compute';

$route['payroll'] ='Payroll_controller/payroll';

$route['pay'] ='Payroll_controller/pay';

$route['404_override'] = '';

$route['translate_uri_dashes'] = FALSE;

