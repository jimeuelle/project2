<?php
class Hello_controller extends CI_Controller{

    public function sayHello(){
        $this->load->view('hello');
        
    }
}