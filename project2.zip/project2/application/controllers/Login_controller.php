<?php
class Login_controller extends CI_Controller{

     


    public function login(){
        $page = 'login';

        $data['name'] = $this -> Login_model -> logindata();
        $data['info'] = $this -> Login_model -> myData();
        $this->load->view($page, $data);
       
            
    }
    public function register(){

        $this -> Login_model -> myData();
        redirect(base_url());
        
    }

    public function authenticate(){

        $res = $this -> Login_model -> authenticate(); 

        if ($res == "success"){
            
            redirect("dashboard");
        }
        elseif($res == "error"){
            
            redirect(base_url());
        }
            
    }

}