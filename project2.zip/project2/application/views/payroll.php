<<style>
body {
  background-image: url('hcc.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>


<div class="container">

    <h1> </h1>
    <div class="col-6 bg-secondary">
        <div class="p-5">

        <form action="pay" method="post">
            <div class="mb-2 mt-2">
                <label for="name" class="form-label">Name:</label>
                <input type="text" class="form-control" id="name" placeholder="Enter Employee Name" name="name">
            </div>
            <div class="mb-3">
                <label for="position" class="form-label">Position:</label>
                <select name="position" id="" class="form-control"  required>
                <option value="">Select Position</option>
                <option value="Junior Programmer">Junnior Programmer</option>
                <option value="Mid Programmer">Mid Programmer</option>
                <option value="Senior Programmer">Senior Programmer</option>
                <option value="Project Manager">Project manager</option>
            </select>
            </div>
            <div class="mb-2">
                <label for="present" class="form-label">Present days:</label>
                <input type="number" class="form-control" id="present" placeholder="Enter Days Present" name="present">
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>


        
    </div> 
    </div>
</div>