<?php
class Dashboard_controller extends CI_Controller{


    public function dashboard(){
        $this->load->view('template/header');
        $this->load->view('dashboard');
        $this->load->view('template/footer');
            
    }






}