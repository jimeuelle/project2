<<style>
body {
  background-image: url('hcc.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>

    <h1> This is Dashboard</h1>

    
