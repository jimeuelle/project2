<<style>
body {
  background-image: url('hcc.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
    



<div class="container">
    <h1>This is Grade Compute</h1>

    <div class="col-5 bg-secondary">
        <div class="p-5">

        <form action="compute" method="post">
            <div class="mb-2 mt-2">
                <label for="prelim" class="form-label">Prelim:</label>
                <input type="number" class="form-control" id="prelim" placeholder="Enter Prelim" name="prelim">
            </div>
            <div class="mb-2">
                <label for="midterm" class="form-label">Midterm:</label>
                <input type="number" class="form-control" id="midterm" placeholder="Enter Midterm" name="midterm">
            </div>
            <div class="mb-2">
                <label for="=finals" class="form-label">Finals:</label>
                <input type="number" class="form-control" id="finals" placeholder="Enter Finals" name="finals">
            </div>

            <button type="submit" class="btn btn-primary">Compute</button>
        </form>


        <h1>Prelim: <?= $prelim;?></h1>
        <h1>Midterm: <?= $midterm;?></h1>
        <h1>Finals: <?= $final;?></h1>
        <h1>Remarks: <?= $remarks;?></h1>
        <h1>Final Grade: <?= $finalgrade;?></h1>
    </div> 
    </div>
</div>